#!/usr/bin/env python3

"""This program plays a game of Rock, Paper, Scissors between two Players,
and reports both Player's scores each round."""
import random

moves = ['rock', 'paper', 'scissors']


class Player:

    score = 0

    def __init__(self):
        self.my_move = None
        self.their_move = None

    def learn(self, my_move, their_move):
        self.their_move = their_move
        self.my_move = my_move


class RandomPlayer(Player):

    def move(self):
        return random.choice(moves)

    def learn(self, my_move, their_move):
        self.their_move = their_move
        self.my_move = my_move


class HumanPlayer(Player):
    def move(self):
        while True:
            move = input('rock, paper, or scissors: ').lower()
            if move in moves:
                return move
            print("wrong choice, please enter the correct choice")

    def learn(self, my_move, their_move):
        self.their_move = their_move
        self.my_move = my_move


class ReflectPlayer(Player):

        
    def move(self):
        if self.their_move is None:
            return random.choice(moves)
        else:
            return self.their_move

    def learn(self, my_move, their_move):
        self.their_move = their_move
        self.my_move = my_move


class CyclePlayer(Player):

    def move(self):
        if self.my_move is None:
            return random.choice(moves)
        else:
            index = moves.index(self.my_move) + 1
            if index == len(moves):
                index = 0
            return moves[index]

def beats(one, two):
    return ((one == 'rock' and two == 'scissors') or
            (one == 'scissors' and two == 'paper') or
            (one == 'paper' and two == 'rock'))

        

class Game:

    def __init__(self, p1, p2):
        self.p1 = p1
        self.p2 = p2
        self.score_p1 = 0
        self.score_p2 = 0

    def play_round(self):

        move1 = self.p1.move()
        move2 = self.p2.move()
        print(f"Player 1: {move1}  Player 2: {move2}")
        self.p1.learn(move1, move2)
        self.p2.learn(move2, move1)
        print(f" Player 1: {move1}  Player 2: {move2}")
        if beats(move1, move2):
            self.score_p1 += 1
            print("Player 1 wins, check out the score! ")
        elif beats(move2, move1):
            self.score_p2 += 1
            print("Player 2 wins, watch out now! ")
        else:
            print("No winners, because, it's a Tie! ")
            print(f'Player 1 score: {self.score_p1}', f'Player 2 score: {self.score_p2}')
        self.p1.learn(move1, move2)
        self.p2.learn(move2, move1)

    def learn(self, my_move, their_move):
         self.their_move = their_move
         self.my_move = my_move

    def play_game(self):
        print("Game start!")
        for round in range(3):
            print(f"Round {round}:")
            self.play_round()
        print(f"Come back to play again! Total score: player1: {self.score_p1}, player2: {self.score_p2}")
        if self.score_p1 > self.score_p2:
            print('Player 1 wins as usual, step your game up Player 2! ')
        elif self.score_p2 > self.score_p1:
            print("Player 2 won this time, Player 1 you are off, aren't you!?!?!? ")
        else:
            print("The game is not fun anymore because it's a TIE...Bogus!")
            print("Game over!")


if __name__ == '__main__':
    game = Game(HumanPlayer(), RandomPlayer())
    game.play_game()
